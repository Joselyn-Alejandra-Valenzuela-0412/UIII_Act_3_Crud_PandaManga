from django.contrib import admin
from .models import Autor
# Register your models here.

admin.site.register(Autor)
