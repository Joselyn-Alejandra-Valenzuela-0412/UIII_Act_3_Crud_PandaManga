from django.urls import path
from empleados_app import views

urlpatterns = [
    path("",views.inicio_vista4,name="inicio_vista4"),
    path("registrarEmpleado/",views.registrarEmpleado,name="registrarEmpleado"),
    path("seleccionarEmpleado/<id_emp>",views.seleccionarEmpleado,name="seleccionarEmpleado"),
    path("editarEmpleado/",views.editarEmpleado,name="editarEmpleado"),
    path("borrarEmpleado/<id_emp>",views.borrarEmpleado,name="borrarEmpleado")
    
]