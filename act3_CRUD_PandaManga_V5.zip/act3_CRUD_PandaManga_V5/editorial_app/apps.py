from django.apps import AppConfig


class EditorialAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'editorial_app'
