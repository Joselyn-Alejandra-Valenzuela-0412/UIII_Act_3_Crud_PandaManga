from django.urls import path
from manga_app import views

urlpatterns = [
    path("",views.inicio_vista3,name="inicio_vista3"),
    path("registrarManga/",views.registrarManga,name="registrarManga"),
    path("seleccionarManga/<id_manga>",views.seleccionarManga,name="seleccionarManga"),
    path("editarManga/",views.editarManga,name="editarManga"),
    path("borrarManga/<id_manga>",views.borrarManga,name="borrarManga")
    
]